from flask import Flask,render_template, request,session,redirect,url_for
from flask_mysqldb import MySQL
import MySQLdb.cursors

app = Flask(__name__)
app.secret_key = 'your secret key'

app.config['MYSQL_HOST']= 'localhost'
app.config['MYSQL_USER']= 'root'
app.config['MYSQL_PASSWORD']='root'
app.config['MYSQL_DB']='IBM'

mysql = MySQL(app)


def login():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username" and "password" POST requests exist (user submitted form)
    # Create variables for easy access
    details = request.form
    username = details['fname']
    password = details['lname']
    print(username)
    print(type(int(password)))
    print('SELECT * FROM nombres WHERE nombre = %s AND edad = %d' % (username, int(password)))
    # Check if account exists using MySQL
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM nombres WHERE nombre = %s AND edad = %s", (username, password))
    # Fetch one record and return result
    account = cursor.fetchone()
    # If account exists in accounts table in out database
    if account:
        # Create session data, we can access this data in other routes
        session['loggedin'] = True
        session['id'] = account['nomId']
        session['username'] = account['nombre']
        # Redirect to home page
        msg= '200'
        return render_template('hello.html', msg=msg,name=session['username'])
    else:
        # Account doesnt exist or username/password incorrect
        msg = 'Incorrect username/password!'
        msg2='400'
        return render_template('insert.html', msg=msg,msg2=msg2)
    # Show the login form with message (if any)
    return render_template('hello.html', msg=msg,name=session['username'])

def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return '200'

@app.route('/logout')
def logoutt():
    msg=logout()
    msg2='Ingresa tus datos'
    return redirect(url_for('login', msg=msg,msg2=msg2))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/mysql')
def basede():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM nombres;')
    fetchdata = cur.fetchall()
    cur.close()
    return render_template('index.html',data=fetchdata)

@app.route('/inicio',methods=['GET','POST'])
def insertar():
    msg='Ingresa tus datos'
    if "reg" in request.form:
        details = request.form
        firstName = details['fname']
        lastName = details['lname']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO nombres(nombre, edad) VALUES (%s, %s)", (firstName, lastName))
        mysql.connection.commit()
        cur.close()
        return render_template('aceptado.html',nombre=firstName)
    elif "jugar" in request.form:
        return basede()
    elif "login" in request.form:
        return login()
    return render_template('insert.html',msg=msg)

@app.route('/user,<name>')
def nombre(name):
    return render_template('hello.html',name=name)

@app.route('/años,<name>,<anios>')
def años(name,anios):
    return render_template('anos.html',meses=anios,name=name)

if __name__ == '__main__':
    app.run(debug=True,port=8001)
