from flask import Flask,render_template, request,session,redirect,url_for
from flask_mysqldb import MySQL
import MySQLdb.cursors

app = Flask(__name__)
app.secret_key = 'your secret key'

app.config['MYSQL_HOST']= 'localhost'
app.config['MYSQL_USER']= 'root'
app.config['MYSQL_PASSWORD']='root'
app.config['MYSQL_DB']='IBM'

mysql = MySQL(app)

@app.route('/inicio',methods=['POST'])
def login():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username" and "password" POST requests exist (user submitted form)
    # Create variables for easy access
    details = request.form
    print('==================================',details)
    print('-----------------------------',details['fname'])
    username = details['fname']
    password = details['lname']
    print(username)
    print(password)
    print('SELECT * FROM nombres WHERE nombre = %s AND edad = %d' % (username, int(password)))
    # Check if account exists using MySQL
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM nombres WHERE nombre = %s AND edad = %s", (username, password))
    # Fetch one record and return result
    account = cursor.fetchone()
    # If account exists in accounts table in out database
    if account:
        # Create session data, we can access this data in other routes
        session['loggedin'] = True
        session['id'] = account['nomId']
        session['username'] = account['nombre']
        # Redirect to home page
        msg= '200'
        return (msg)
    else:
        # Account doesnt exist or username/password incorrect
        msg = '400'
    # Show the login form with message (if any)
    return (msg)

def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return '200'

if __name__ == '__main__':
    app.run(debug=True,port=8001)
